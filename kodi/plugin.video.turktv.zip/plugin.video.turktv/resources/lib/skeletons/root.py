# -*- coding: utf-8 -*-
# Copyright: (c) 2022, itasli
# GNU General Public License v2.0+ (see LICENSE.txt or https://www.gnu.org/licenses/gpl-2.0.txt)

# This file is part of Catch-up TV & More

from __future__ import unicode_literals

# The following dictionaries describe
# the addon's tree architecture.
# * Key: item id
# * Value: item infos
#     - route (folder)/resolver (playable URL): Callback function to run once this item is selected
#     - thumb: Item thumb path relative to "media" folder
#     - fanart: Item fanart path relative to "media" folder

root = 'live_tv'

menu = {
    'trt1': {
        'resolver': '/resources/lib/channels/tr/trt:get_live_url',
        'label': 'TRT 1',
        'thumb': 'https://i.ibb.co/yqVzg0Y/trt-1-tr.png',
        'enabled': True,
        'order': 1
    },
    'atvhd': {
        'resolver': '/resources/lib/channels/tr/turkuvaz:get_live_url',
        'label': 'atv',
        'thumb': 'https://i.ibb.co/qjTQBnK/atv-tr.png',
        'enabled': True,
        'order': 2
    },
    'atvavrupa': {
        'resolver': '/resources/lib/channels/tr/turkuvaz:get_live_url',
        'label': 'atv Avrupa',
        'thumb': 'https://i.ibb.co/VWWsddy/atv-avrupa-tr.png',
        'enabled': True,
        'order': 3
    },
    'showtv': {
        'resolver': '/resources/lib/channels/tr/cinergroup:get_live_url',
        'label': 'Show TV',
        'thumb': 'https://i.ibb.co/fthP6xt/show-tr.png',
        'enabled': True,
        'order': 4
    },
    'showturk': {
        'resolver': '/resources/lib/channels/tr/cinergroup:get_live_url',
        'label': 'Show Türk',
        'thumb': 'https://i.ibb.co/CnvYSVQ/show-turk-tr.png',
        'enabled': True,
        'order': 5
    },
    'star': {
        'resolver': '/resources/lib/channels/tr/star:get_live_url',
        'label': 'Star TV',
        'thumb': 'https://i.ibb.co/YpMLCcg/star-tv-tr.png',
        'enabled': True,
        'order': 6
    },
    'eurostar': {
        'resolver': '/resources/lib/channels/tr/eurostar:get_live_url',
        'label': 'Euro Star',
        'thumb': 'https://i.ibb.co/c676Mjq/euro-star-tr.png',
        'enabled': True,
        'order': 7
    },
    'kanald': {
        'resolver': '/resources/lib/channels/tr/dogan:get_live_url',
        'label': 'Kanal D',
        'thumb': 'https://i.ibb.co/B6sfdLt/kanal-d-tr.png',
        'enabled': True,
        'order': 8
    },
    'eurod': {
        'resolver': '/resources/lib/channels/tr/dogan:get_live_url',
        'label': 'Euro D',
        'thumb': 'https://i.ibb.co/tL0c1Y1/euro-d-tr.png',
        'enabled': True,
        'order': 9
    },
    'fox': {
        'resolver': '/resources/lib/channels/tr/fox:get_live_url',
        'label': 'FOX',
        'thumb': 'https://i.ibb.co/f1x24Yk/fox-tr.png',
        'enabled': True,
        'order': 10
    },
    'kanal7': {
        'resolver': '/resources/lib/channels/tr/kanal7:get_live_url',
        'label': 'Kanal 7',
        'thumb': 'https://i.ibb.co/ydzp5Vp/kanal-7-tr.png',
        'enabled': True,
        'order': 11
    },
    'kanal7avrupa': {
        'resolver': '/resources/lib/channels/tr/kanal7:get_live_url',
        'label': 'Kanal 7 Avrupa',
        'thumb': 'https://i.ibb.co/XF3CdBG/kanal-7-avrupa-tr.png',
        'enabled': True,
        'order': 12
    },
    'tv8': {
        'resolver': '/resources/lib/channels/tr/tv8:get_live_url',
        'label': 'TV 8',
        'thumb': 'https://i.ibb.co/1GWCwzD/tv8-tr.png',
        'enabled': True,
        'order': 13
    },
    'tv8int': {
        'resolver': '/resources/lib/channels/tr/tv8:get_live_url',
        'label': 'TV 8 Int',
        'thumb': 'https://i.ibb.co/sCpNt3s/tv8-int-tr.png',
        'enabled': True,
        'order': 14
    },
    'teve2': {
        'resolver': '/resources/lib/channels/tr/teve2:get_live_url',
        'label': 'Teve2',
        'thumb': 'https://i.ibb.co/Nyhscsy/teve2-tr.png',
        'enabled': True,
        'order': 15
    },
    '360tv': {
        'resolver': '/resources/lib/channels/tr/360tv:get_live_url',
        'label': '360 TV',
        'thumb': 'https://i.ibb.co/kyw3Vt2/360-tr.png',
        'enabled': True,
        'order': 16
    },
    'beyaz': {
        'resolver': '/resources/lib/channels/tr/beyaz:get_live_url',
        'label': 'Beyaz TV',
        'thumb': 'https://i.ibb.co/Z1cjYBM/beyaz-tv-tr.png',
        'enabled': True,
        'order': 17
    },
    'a2tv': {
        'resolver': '/resources/lib/channels/tr/turkuvaz:get_live_url',
        'label': 'a2',
        'thumb': 'https://i.ibb.co/10SjpQ4/a2-tr.png',
        'enabled': True,
        'order': 18
    },
    'showmax': {
        'resolver': '/resources/lib/channels/tr/cinergroup:get_live_url',
        'label': 'Show MAX',
        'thumb': 'https://i.ibb.co/k6JGmqQ/show-max-tr.png',
        'enabled': True,
        'order': 19
    },
    'cine5': {
        'resolver': '/resources/lib/channels/tr/cine5:get_live_url',
        'label': 'Cine5',
        'thumb': 'https://i.ibb.co/xfyYtP6/cine5.png',
        'enabled': True,
        'order': 20
    },
    'trtcocuk': {
        'resolver': '/resources/lib/channels/tr/trt:get_live_url',
        'label': 'TRT Çocuk',
        'thumb': 'https://i.ibb.co/G2VNWnP/trt-cocuk-tr.png',
        'enabled': True,
        'order': 21
    },
    'minikagococuk': {
        'resolver': '/resources/lib/channels/tr/turkuvaz:get_live_url',
        'label': 'Minika Çocuk',
        'thumb': 'https://i.ibb.co/Wfhmr34/minika-cocuk-tr.png',
        'enabled': True,
        'order': 22
    },
    'minikago': {
        'resolver': '/resources/lib/channels/tr/turkuvaz:get_live_url',
        'label': 'Minika Go',
        'thumb': 'https://i.ibb.co/7YRc8NJ/minika-go-tr.png',
        'enabled': True,
        'order': 23
    },
    'ahaberhd': {
        'resolver': '/resources/lib/channels/tr/turkuvaz:get_live_url',
        'label': 'A Haber',
        'thumb': 'https://i.ibb.co/vz1xxtG/a-haber-tr.png',
        'enabled': True,
        'order': 24
    },
    'aparahd': {
        'resolver': '/resources/lib/channels/tr/turkuvaz:get_live_url',
        'label': 'A Para',
        'thumb': 'https://i.ibb.co/MBjnkCM/a-para-tr.png',
        'enabled': True,
        'order': 25
    },
    'bloomberght': {
        'resolver': '/resources/lib/channels/tr/cinergroup:get_live_url',
        'label': 'Bloomberg HT',
        'thumb': 'https://i.ibb.co/GRxmbCz/bloomberg-ht-tr.png',
        'enabled': True,
        'order': 26
    },
    'cnnturk': {
        'resolver': '/resources/lib/channels/tr/cnnturk:get_live_url',
        'label': 'CNN TURK',
        'thumb': 'https://i.ibb.co/WPMDPTR/cnn-turk-tr.png',
        'enabled': True,
        'order': 27
    },
    'haberglobal': {
        'resolver': '/resources/lib/channels/tr/haberglobal:get_live_url',
        'label': 'Haber Global',
        'thumb': 'https://i.ibb.co/9tdyN3r/haber-global-tr.png',
        'enabled': True,
        'order': 28
    },
    'haberturk': {
        'resolver': '/resources/lib/channels/tr/cinergroup:get_live_url',
        'label': 'Haber Türk',
        'thumb': 'https://i.ibb.co/f9B1wcP/haberturk-tr.png',
        'enabled': True,
        'order': 29
    },
    'ntv': {
        'resolver': '/resources/lib/channels/tr/ntv:get_live_url',
        'label': 'NTV',
        'thumb': 'https://i.ibb.co/k8X214n/ntv.png',
        'enabled': True,
        'order': 30
    },
    'tvnet': {
        'resolver': '/resources/lib/channels/tr/tvnet:get_live_url',
        'label': 'Tvnet',
        'thumb': 'https://i.ibb.co/TRTmWRN/tvnet-tr.png',
        'enabled': True,
        'order': 31
    },
    '24tv': {
        'resolver': '/resources/lib/channels/tr/24tv:get_live_url',
        'label': '24 TV',
        'thumb': 'https://i.ibb.co/VVjtgsP/24-tr.png',
        'enabled': True,
        'order': 32
    },
    'tgrthaber': {
        'resolver': '/resources/lib/channels/tr/tgrt:get_live_url',
        'label': 'TGRT Haber',
        'thumb': 'https://i.ibb.co/vqxkmpV/tgrt-haber-tr.png',
        'enabled': True,
        'order': 33
    },    
    'trthaber': {
        'resolver': '/resources/lib/channels/tr/trt:get_live_url',
        'label': 'TRT Haber',
        'thumb': 'https://i.ibb.co/CBkKk3q/trt-haber-tr.png',
        'enabled': True,
        'order': 34
    },
    'tele1': {
        'resolver': '/resources/lib/channels/tr/tele1:get_live_url',
        'label': 'Tele 1',
        'thumb': 'https://i.ibb.co/bQ3NRSP/tele1-tr.png',
        'enabled': True,
        'order': 35
    },
    'tv5': {
        'resolver': '/resources/lib/channels/tr/tv5:get_live_url',
        'label': 'TV 5',
        'thumb': 'https://i.ibb.co/1Mp9P2w/tv5-tr.png',
        'enabled': True,
        'order': 36
    },
    'ulke': {
        'resolver': '/resources/lib/channels/tr/ulke:get_live_url',
        'label': 'Ulke TV',
        'thumb': 'https://i.ibb.co/BZXCfRh/ulke-tv-tr.png',
        'enabled': True,
        'order': 37
    },
    'dmax': {
        'resolver': '/resources/lib/channels/tr/dogus:get_live_url',
        'label': 'DMAX',
        'thumb': 'https://i.ibb.co/yk9vNYJ/dmax.png',
        'enabled': True,
        'order': 38
    },
    'tlc': {
        'resolver': '/resources/lib/channels/tr/dogus:get_live_url',
        'label': 'TLC',
        'thumb': 'https://i.ibb.co/2FB3Q5F/tlc.png',
        'enabled': True,
        'order': 39
    },
    'trt2': {
        'resolver': '/resources/lib/channels/tr/trt:get_live_url',
        'label': 'TRT 2',
        'thumb': 'https://i.ibb.co/8b0BfFP/trt-2-tr.png',
        'enabled': True,
        'order': 40
    },
    'trtavaz': {
        'resolver': '/resources/lib/channels/tr/trt:get_live_url',
        'label': 'TRT Avaz',
        'thumb': 'https://i.ibb.co/c3f6pqL/trt-avaz-tr.png',
        'enabled': True,
        'order': 41
    },
    'trtbelgesel': {
        'resolver': '/resources/lib/channels/tr/trt:get_live_url',
        'label': 'TRT Belgesel',
        'thumb': 'https://i.ibb.co/TB0HFyx/trt-belgesel-tr.png',
        'enabled': True,
        'order': 42
    },
    'asporhd': {
        'resolver': '/resources/lib/channels/tr/turkuvaz:get_live_url',
        'label': 'A Spor',
        'thumb': 'https://i.ibb.co/YWqhJqM/a-spor-tr.png',
        'enabled': True,
        'order': 43
    },
    'vavtv': {
        'resolver': '/resources/lib/channels/tr/turkuvaz:get_live_url',
        'label': 'Vav TV',
        'thumb': 'https://i.ibb.co/7vFcm95/vav-tv-tr.png',
        'enabled': True,
        'order': 44
    },
}
